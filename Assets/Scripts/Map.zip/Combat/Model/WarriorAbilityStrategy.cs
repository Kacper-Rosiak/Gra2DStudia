using System;

public class WarriorAbilityStrategy : IAbilityStrategy
{
    public string AbilityName => "Uderzenie Tarcz�";

    public event Action<string> OnAbilityVisualsTriggered;

    public void Execute(Entity caster, Entity target, Action<string> logCallback)
    {
        // Model-View: Wywo�anie zdarzenia dla widoku
        OnAbilityVisualsTriggered?.Invoke("ShieldBash_VFX");

        // Logika: Obra�enia = Atak + Obrona atakuj�cego - Obrona celu
        int damage = Math.Max(1, (caster.Attack + caster.Defense) - target.Defense);
        target.TakeDamage(damage);

        logCallback?.Invoke($"{caster.Name} u�ywa {AbilityName}! Zadaje {damage} obra�e� postaci {target.Name}.");

        // Szansa na og�uszenie (np. 50%)
        Random rnd = new Random();
        if (rnd.Next(0, 100) < 50)
        {
            target.IsStunned = true;
            logCallback?.Invoke($"{target.Name} zostaje og�uszony i traci nast�pn� tur�!");
        }
    }
}