// CombatEnums.cs
// Definicje faz maszyny stan�w
public enum BattleState
{
    Setup,          // Inicjalizacja walki i kolejki
    PlayerTurn,     // Oczekiwanie na akcj� gracza
    EnemyTurn,      // AI wykonuje ruch
    Resolution,     // Obliczanie skutk�w akcji i sprawdzanie czy kto� zgin��
    End             // Zako�czenie walki
}

// Mo�liwe wyniki starcia
public enum BattleResult
{
    Victory,
    Defeat,
    Escaped
}
