using System;

public interface IAbilityStrategy
{
    string AbilityName { get; }

    // Zdarzenie dla warstwy View (np. "Odtw�rz cz�steczki ognia", "Zagraj d�wi�k tarczy")
    event Action<string> OnAbilityVisualsTriggered;

    void Execute(Entity caster, Entity target, Action<string> logCallback);
}