using System;

public class AssassinAbilityStrategy : IAbilityStrategy
{
    public string AbilityName => "Zatruty Sztylet";

    public event Action<string> OnAbilityVisualsTriggered;

    public void Execute(Entity caster, Entity target, Action<string> logCallback)
    {
        // Sygna� dla widoku (np. zielony rozb�ysk)
        OnAbilityVisualsTriggered?.Invoke("PoisonDagger_VFX");

        // Cios precyzyjny: obra�enia skaluj� si� z Atakiem oraz po�ow� Szybko�ci
        int damage = Math.Max(1, (caster.Attack + (caster.Speed / 2)) - target.Defense);
        target.TakeDamage(damage);

        logCallback?.Invoke($"{caster.Name} atakuje z cienia u�ywaj�c {AbilityName}! Zadaje {damage} obra�e� postaci {target.Name}.");

        // Nak�adanie statusu trucizny (podobnie jak podpalenie u Maga)
        target.OnTurnStart += ApplyPoisonDamage;
        logCallback?.Invoke($"{target.Name} zostaje zatruty!");
    }

    private void ApplyPoisonDamage(Entity affectedEntity, Action<string> logCallback)
    {
        int poisonDamage = 4;
        affectedEntity.TakeDamage(poisonDamage);
        logCallback?.Invoke($"<color=green>[Trucizna]</color> {affectedEntity.Name} traci {poisonDamage} HP z powodu dzia�ania jadu!");
    }
}