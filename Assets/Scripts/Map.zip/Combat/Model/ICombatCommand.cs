// ICombatCommand.cs
public interface ICombatCommand
{
    // G��wna funkcja wykonuj�ca polecenie (np. zadanie obra�e�)
    void Execute();
}