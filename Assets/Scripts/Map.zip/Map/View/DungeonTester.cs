using UnityEngine;
using UnityEngine.InputSystem;
using DungeonCore.Map.Model; // Pobiera informacje z naszej warstwy danych

namespace DungeonCore.Map.View
{
    public class DungeonTester : MonoBehaviour
    {
        private DungeonManager _dungeonManager;

        void Start()
        {
            // Inicjalizuje mened�era, co powoduje wygenerowanie grafu podziemi.
            // Buforowanie pierwszego pokoju na samym pocz�tku u�atwia p�niejsze umieszczenie gracza na mapie.
            _dungeonManager = new DungeonManager();

            // Podpi�cie pod zdarzenie: za ka�dym razem, gdy zmieni si� pok�j, wypisz to w konsoli.
            _dungeonManager.OnRoomChanged += (room) =>
            {
                Debug.Log($"Gracz wszed� do pokoju typu: {room.Type} na wsp�rz�dnych {room.Position}");
            };
        }

        void Update()
        {
            // Zabezpieczenie przed brakiem klawiatury
            if (Keyboard.current == null) return;

            // Nas�uchiwanie wci�ni�cia strza�ek z u�yciem nowego systemu
            if (Keyboard.current.upArrowKey.wasPressedThisFrame)
            {
                TryMove(Direction.North, "P�noc");
            }
            else if (Keyboard.current.downArrowKey.wasPressedThisFrame)
            {
                TryMove(Direction.South, "Po�udnie");
            }
            else if (Keyboard.current.rightArrowKey.wasPressedThisFrame)
            {
                TryMove(Direction.East, "Wsch�d");
            }
            else if (Keyboard.current.leftArrowKey.wasPressedThisFrame)
            {
                TryMove(Direction.West, "Zach�d");
            }
        }

        // Metoda pomocnicza wykonuj�ca ruch i sprawdzaj�ca, czy uderzyli�my w �cian�
        private void TryMove(Direction direction, string directionName)
        {
            bool success = _dungeonManager.MoveTo(direction);

            if (!success)
            {
                Debug.Log($"Uderzy�e� w �cian�! Brak przej�cia na wektorze: {directionName}.");
            }
        }
    }
}