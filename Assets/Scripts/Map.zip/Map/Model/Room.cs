using DungeonCore.Map.Model;
using System.Collections.Generic;
using UnityEngine;

namespace DungeonCore.Map.Model
{
    /// <summary>
    /// Reprezentuje zhermetyzowany, pojedynczy w�ze� logiczny w z�o�onym grafie lochu.
    /// Obiekt jest ca�kowicie wyizolowany z p�tli �ycia silnika Unity, gwarantuj�c wydajno�� POCO.
    /// </summary>
    public class Room
    {
        /// <summary>
        /// Bezwzgl�dne koordynaty pokoju w dyskretnej, dwuwymiarowej przestrzeni kartezja�skiej Z^2.
        /// Wykorzystanie Vector2Int chroni przed problemami z b��dami zmiennoprzecinkowymi (Floating Point Inaccuracies).
        /// </summary>
        public Vector2Int Position { get; private set; }

        /// <summary>
        /// Typologiczna, narracyjna rola pokoju dyktuj�ca jego przysz�� zawarto�� 
        /// mechaniczn� na poziomie silnika gry.
        /// </summary>
        public RoomType Type { get; private set; }

        /// <summary>
        /// S�ownik struktur generycznych przechowuj�cy kraw�dzie grafu (s�siedztwa i drzwi). 
        /// Kluczem wyszukiwania jest wyliczenie kierunku, warto�ci� - bezpo�rednia referencja w pami�ci.
        /// Gwarantuje niezr�wnan� amortyzowan� z�o�ono�� wyszukiwania O(1).
        /// </summary>
        public Dictionary<Direction, Room> Neighbors { get; private set; }

        /// <summary>
        /// Konstruktor alokuj�cy i inicjalizuj�cy fundamentalny stan pokoju na podstawie 
        /// wstrzykni�tych parametr�w koordynacyjnych.
        /// </summary>
        public Room(Vector2Int position, RoomType type)
        {
            Position = position;
            Type = type;
            // Alokacja instancji s�ownika na stercie w momencie tworzenia w�z�a
            Neighbors = new Dictionary<Direction, Room>();
        }

        /// <summary>
        /// Definiuje i rejestruje kraw�d� pomi�dzy wierzcho�kami w obr�bie danego w�z�a.
        /// </summary>
        /// <param name="direction">Znormalizowany wektor wyj�ciowy (miejsce wstawienia drzwi).</param>
        /// <param name="room">Referencja wska�nikowa na pok�j docelowy.</param>
        public void AddNeighbor(Direction direction, Room room)
        {
            // Ochrona integralno�ci kolekcji przed pr�b� nadpisania przypisanej kraw�dzi
            // lub dodania zduplikowanego klucza, co spowodowa�oby wyj�tek czasowy (Runtime Exception).
            if (!Neighbors.ContainsKey(direction))
            {
                Neighbors.Add(direction, room);
            }
        }
    }
}