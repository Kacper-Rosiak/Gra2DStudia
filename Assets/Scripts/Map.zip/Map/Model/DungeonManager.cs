using DungeonCore.Map.Model;
using System;

namespace DungeonCore.Map.Model
{
    /// <summary>
    /// Integralna klasa �rodowiskowa steruj�ca bezb��dnie logik� liniowego i nieliniowego 
    /// poruszania si� po wykreowanym matematycznie grafie abstrakcyjnej struktury podziemi.
    /// Pe�ni zaszczytn� funkcj� zwinnego Agenta Kontrolera, zarz�dzaj�c wy��cznym indeksem pokoju.
    /// </summary>
    public class DungeonManager
    {
        /// <summary>
        /// Hermetyczne, wewn�trzne odniesienie do gigantycznej przestrzennej struktury ca�ego lochu (Model Domenowy).
        /// Stanowi jedyne zrod�o prawdy (Single Source of Truth) dla weryfikatora kolizji topologicznej.
        /// </summary>
        public DungeonGraph Graph { get; private set; }

        /// <summary>
        /// Krytyczny wska�nik alokacji pami�ciowej (Index), w czasie rzeczywistym nieub�aganie 
        /// �ledz�cy i weryfikuj�cy referencj� do pokoju bazowego, w kt�rym znajduje si� w tej sekundzie gry
        /// byt przestrzenny taki jak podmiot gracza lub g��wny bohater narracyjny.
        /// Zmiana odniesienia w tym polu w spos�b doskona�y symuluje abstrakcyjne i kosztowne obliczeniowo "przej�cie".
        /// </summary>
        public Room CurrentRoom { get; private set; }

        /// <summary>
        /// C# native event (Zdarzenie deleguj�ce oparte o silnie typowane Action). 
        /// Konstrukcja wybitnie przydatna i wr�cz niezb�dna do ca�kowicie bezproblemowej 
        /// integracji z asynchronicznym, docelowym wielow�tkowym �rodowiskiem UI 
        /// w silniku Unity. Stanowi pasywny wektor powiadamiaj�cy zewn�trzny modu� widoku
        /// o nowej dystrybucji element�w �rodowiskowych bez twardego sprz�gania architektury (loose coupling).
        /// </summary>
        public event Action<Room> OnRoomChanged;

        /// <summary>
        /// Wywo�anie konstruktora bezpiecznie inicjalizuje hermetyczn� logik� poprzez bezkompromisowe wykreowanie 
        /// ca�kowicie suwerennej instancji skomplikowanego grafu w�z�owego mapy oraz narzucenie
        /// domy�lnego wektora pozycji obiektu gracza dok�adnie na progu wygenerowanego �rodowiska (StartRoom).
        /// </summary>
        public DungeonManager()
        {
            // Natychmiastowe utworzenie strukturalne przy tworzeniu mened�era
            Graph = new DungeonGraph();

            // Konieczno�� buforowania i tak zwanego "cache'owania pierwszego punktu styku". 
            // Znalezienie koordynat w matrycach o rozmiarze milion�w jednostek kwadratowych  
            // bez tej logiki po�ar�oby ogromny odsetek cykli na poszukiwanie (Search Time).
            CurrentRoom = Graph.StartRoom;

            // Niespodziewana dereferencja wska�nikowa mog�aby zawiesi� logik� systemow�.
            if (CurrentRoom != null)
            {
                // Inicjalizacyjne opublikowanie globalnego stanu �rodowiskowego na potrzeby test�w
                OnRoomChanged?.Invoke(CurrentRoom);
            }
            else
            {
                // Ekstremalne b��dy na warstwie grafowej winny generowa� hard-crash przy testach jednostkowych.
                throw new InvalidOperationException("Inicjalizacja �rodowiska zaniechana. Graf lochu nie posiada prawid�owo alokowanego punktu startowego StartRoom.");
            }
        }

        /// <summary>
        /// Rdze� mechaniki testowej podmiotu - wysoce zoptymalizowana wirtualna metoda ruchu. 
        /// Bezkompromisowo weryfikuje oraz (wyst�puj�c w warunkach absolutnej pewno�ci logicznej)
        /// pomy�lnie wykonuje nag�� cyfrow� tranzycj� w rygorystycznie zadanym przez strumie� wej�cia
        /// kierunku wektorowym opartym na ortogonalnych osiach odniesienia kartezja�skiego.
        /// Ca�kowicie izoluje z�o�ono�� warstwy danych, zr�cznie ukrywaj�c proces sprawdzania kolekcji grafu.
        /// </summary>
        /// <param name="dir">Skompresowany do warto�ci wyliczeniowej kierunek, na wektorze kt�rego agent zlecaj�cy dokonuje pr�by tranzycji geometrycznej.</param>
        /// <returns>Logiczna flaga potwierdzaj�ca stan - Prawda (true), gwarantuj�ca pomy�ln� synchronizacj� przej�cia wska�nikowego, w ka�dym innym defektywnym wypadku - Fa�sz (false).</returns>
        public bool MoveTo(Direction dir)
        {
            // Operacja si�ga g��boko do wn�trzno�ci wyizolowanego w�z�a i wy�uskuje dane przy u�yciu 
            // pot�nego wariantu czasowego wyszukiwania s�ownikowego TryGetValue o skali absolutnej O(1).
            // Niszczy to w zarodku b��dy nadmiernego iterowania matryc wielowymiarowych uci��liwych w starych paradygmatach.
            if (CurrentRoom.Neighbors.TryGetValue(dir, out Room destinationRoom))
            {
                // Fizyczna podmiana wyabstrahowanego z przestrzeni 3D wska�nika (przypisanie nowego indeksu w�z�a referencyjnego)
                CurrentRoom = destinationRoom;

                // Bezzw�oczna, pozbawiona cykli zatrzymuj�cych (blocking cycles) powszechna emisja zdarzenia powiadamiaj�cego
                // warstw� dewelopersk� zintegrowan� lub ostateczny system warstwy widoku w silniku 
                // o diametralnej reorientacji geometrii wok� agenta, zlecaj�c zmian� renderingu lub logowania zdarze�.
                OnRoomChanged?.Invoke(CurrentRoom);

                return true; // Stan symulacji zaktualizowany i zweryfikowany z ca�kowitym sukcesem
            }

            // Osi�gni�cie tej strefy powrotnej implikuje krytyczny brak definicji kraw�dzi nawigacyjnej, zjawisko uderzenia w pustk� lub �cian� absolutn�. 
            // Odmowa autoryzacji przesuni�cia wektora zabezpiecza ca�� fizyk� silnika przed wyj�ciem za ramy tablicy indeks�w.
            // Bezpieczne zatrzymanie bez u�ycia wyj�tku.
            return false;
        }
    }
}