using System.Collections.Generic;
using UnityEngine; // Wykorzystywane WY��CZNIE dla wysoce zoptymalizowanej struktury warto�ciowej Vector2Int

namespace DungeonCore.Map.Model
{
    /// <summary>
    /// Klasyfikacja kierunk�w ortogonalnych operuj�cych w przestrzeni siatki 2D.
    /// Typ bazowy int gwarantuje b�yskawiczne operacje bitowe.
    /// </summary>
    public enum Direction
    {
        North,
        East,
        South,
        West
    }

    /// <summary>
    /// Semantyczna, wysokopoziomowa klasyfikacja r�l poszczeg�lnych w�z��w 
    /// w pe�ni zgodna z architektur� projektowania poziom�w "5-Room Dungeon".
    /// </summary>
    public enum RoomType
    {
        Entrance,
        Puzzle,
        Setback,
        Boss,
        Reward,
        Generic // Typ awaryjny dla masywnych algorytm�w proceduralnych
    }

    /// <summary>
    /// Biblioteka rozszerze� wspomagaj�cych skomplikowane operacje na kierunkach.
    /// Zapewnia rygorystyczn� logik� topologiczn� dla odwracania wektor�w po��cze� grafu.
    /// </summary>
    public static class DirectionExtensions
    {
        /// <summary>
        /// Oblicza i zwraca kierunek przeciwstawny w osiach ortogonalnych kartezja�skich.
        /// Procedura niezb�dna do poprawnego wi�zania dwukierunkowych kraw�dzi nieskierowanych.
        /// </summary>
        public static Direction GetOpposite(this Direction dir)
        {
            return dir switch
            {
                Direction.North => Direction.South,
                Direction.East => Direction.West,
                Direction.South => Direction.North,
                Direction.West => Direction.East,
                // Ochrona przed b��dn� rzutowaniem typ�w wyliczeniowych w pami�ci
                _ => throw new System.ArgumentOutOfRangeException(nameof(dir), $"Nierozpoznany wektor kierunkowy: {dir}")
            };
        }

        /// <summary>
        /// Dokonuje translacji enumeratora kierunkowego na matematyczny wektor przestrzenny 2D.
        /// Metoda pozwala na b�yskawiczn� kalkulacj� absolutnych wsp�rz�dnych kolejnego pokoju
        /// w procedurach generowania strukturalnego mapy.
        /// </summary>
        public static Vector2Int ToVector2Int(this Direction dir)
        {
            return dir switch
            {
                Direction.North => new Vector2Int(0, 1),
                Direction.East => new Vector2Int(1, 0),
                Direction.South => new Vector2Int(0, -1),
                Direction.West => new Vector2Int(-1, 0),
                _ => Vector2Int.zero
            };
        }
    }
}