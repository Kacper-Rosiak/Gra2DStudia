using DungeonCore.Map.Model;
using System.Collections.Generic;
using UnityEngine;

namespace DungeonCore.Map.Model
{
    /// <summary>
    /// Rozleg�a struktura architektoniczna, w pe�ni odpowiedzialna za definicj� ca�ego grafu mapy.
    /// Nadzoruje sp�jno�� wska�nikow� i pami�ciow� wszystkich zagnie�d�onych w nim logicznie w�z��w.
    /// </summary>
    public class DungeonGraph
    {
        // Prywatny, globalny rejestr wszystkich w�z��w, mapuj�cy wektor pozycji na konkretny pok�j.
        // Tworzy zoptymalizowany indeks przestrzenny, diametralnie przyspieszaj�c zapytania strukturalne O(1).
        private Dictionary<Vector2Int, Room> _roomRegistry;

        /// <summary>
        /// Niezmienny punkt centralny i wej�ciowy - absolutny korze� grafu w�z�owego mapy.
        /// </summary>
        public Room StartRoom { get; private set; }

        public DungeonGraph()
        {
            _roomRegistry = new Dictionary<Vector2Int, Room>();
            BuildStaticTestMap();
        }

        /// <summary>
        /// Enkapsuluje z�o�on� logik� gwarantuj�c� matematycznie sp�jne i obustronne powi�zanie 
        /// pomi�dzy dwoma dynamicznymi w�z�ami na rygorystycznie zadanym wektorze kierunku. 
        /// Operacja symetryczna: Je�li w�ze� A spogl�da na P�noc w stron� w�z�a B, 
        /// wektor B si�� narzuca spojrzenie na Po�udnie wzgl�dem w�z�a A.
        /// </summary>
        private void ConnectRooms(Room roomA, Direction dirAtoB, Room roomB)
        {
            // Ochrona przed krytycznym b��dem NullReferenceException psuj�cym integralno�� silnika.
            if (roomA == null || roomB == null) return;

            // Inicjalizacja kraw�dzi w wektorze natarcia...
            roomA.AddNeighbor(dirAtoB, roomB);

            //...i natychmiastowe zdefiniowanie wektora powrotnego za spraw� metod rozszerzaj�cych.
            Direction oppositeDir = dirAtoB.GetOpposite();
            roomB.AddNeighbor(oppositeDir, roomA);
        }

        /// <summary>
        /// Konstruuje w pami�ci niezwykle rygorystyczn� logicznie, z g�ry przewidzian� map� testow�.
        /// Sk�ada si� ona z wysoce zoptymalizowanych, zdefiniowanych "na sztywno" koordynat.
        /// </summary>
        private void BuildStaticTestMap()
        {
            /* Deklaratywny schemat przestrzenny - Topologia "Krzy�a/Litery T" (5-node cross subgraph):
             * Uk�ad ten unika b��du linearno�ci i stwarza pole do podejmowania wielo�cie�kowych decyzji.
             *
             *                  (0, 2)
             * | (P�noc/Po�udnie)
             * [Puzzle ] (0, 0) -- (0, 1) -- (1, 1)  <-- (Wsch�d/Zach�d)
             * | (P�noc/Po�udnie)
             *                 [Entrance] (0, -1)
             */

            // Faza 1: Instancjonowanie obiekt�w strukturalnych w�z��w i nadawanie r�l narracyjnych.
            Room entrance = new Room(new Vector2Int(0, -1), RoomType.Entrance);
            Room setback = new Room(new Vector2Int(0, 1), RoomType.Setback);
            Room puzzle = new Room(new Vector2Int(0, 0), RoomType.Puzzle);
            Room boss = new Room(new Vector2Int(0, 2), RoomType.Boss);
            Room reward = new Room(new Vector2Int(1, 1), RoomType.Reward);

            // Faza 2: Dynamiczna rejestracja w�z��w w super-wydajnym indeksie przestrzennym.
            _roomRegistry.Add(entrance.Position, entrance);
            _roomRegistry.Add(puzzle.Position, puzzle);
            _roomRegistry.Add(setback.Position, setback);
            _roomRegistry.Add(boss.Position, boss);
            _roomRegistry.Add(reward.Position, reward);

            // Faza 3: Fizyczne "kucie w kamieniu" nieodwracalnych kraw�dzi uk�adu przestrzennego.
            // Oparte na bezpiecznej metodzie automatycznie dbaj�cej o wektory odwrotne.
            ConnectRooms(entrance, Direction.North, puzzle);
            ConnectRooms(puzzle, Direction.North, setback);
            ConnectRooms(setback, Direction.North, boss);
            ConnectRooms(setback, Direction.East, reward);

            // Wyj�tkowo kluczowe w dewelopmencie: Zapisanie wska�nika korzenia przestrzennego,
            // zapobiegaj�c konieczno�ci �mudnego wyszukiwania go przy ponownej inicjalizacji gracza.
            StartRoom = entrance;
        }

        /// <summary>
        /// Umo�liwia zewn�trznym, asynchronicznym systemom (jak np. algorytmy AI nawigacji)
        /// b�yskawiczne pozyskanie bezpo�redniej referencji do pokoju na podanych koordynatach.
        /// </summary>
        public Room GetRoomAt(Vector2Int position)
        {
            // U�ycie paradygmatu TryGetValue ca�kowicie eliminuje nadmiern� alokacj�
            // zg�aszania wyj�tk�w w przypadku odpytywania pustych wsp�rz�dnych "czarnej przestrzeni".
            if (_roomRegistry.TryGetValue(position, out Room room))
            {
                return room;
            }
            return null;
        }
    }
}