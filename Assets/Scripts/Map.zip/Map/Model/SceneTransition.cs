using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelTransition : MonoBehaviour
{
    private string sceneToLoad = "DungeonScene";

    private void OnTriggerEnter2D(Collider2D collision)
    {
        // Upewnij si�, �e obiekt, kt�ry wszed� w trigger, to gracz (np. sprawdzaj�c Tag)
        if (collision.CompareTag("Player"))
        {
            SceneManager.LoadScene(sceneToLoad);
        }
    }
}